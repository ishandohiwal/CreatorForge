# CreatorForge — Creator Toolkit

A self-contained creator toolkit designed for static hosting such as GitHub Pages.

## Included
- YouTube thumbnail, square post, banner and story presets
- Canvas editor with text, rectangles, circles and local image uploads
- Drag-to-position elements
- Text/font/color/opacity/rotation controls
- Layers, undo/redo, zoom
- Solid and gradient backgrounds
- PNG/JPG export
- Local project saving with previews
- Image resize/compress/convert tool (PNG/JPG/WebP)
- Responsive dark UI
- No backend, account, API key or external runtime dependency

## Run
Open `index.html` directly, or host the folder on GitHub Pages.

All project data stays in browser localStorage. Uploaded images are processed locally by the browser.
